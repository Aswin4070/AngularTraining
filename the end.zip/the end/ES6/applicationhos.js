var Hospital = require('./hospital');

var apollo = new Hospital(101, "Apollo Hospital", 575);

console.log(apollo.toString());
console.log(apollo.phone);