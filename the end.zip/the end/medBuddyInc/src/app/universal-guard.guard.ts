import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UniversalGuardGuard implements CanActivate {
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

      const userStatus = sessionStorage.getItem('status');
      let allow = false;
      if (userStatus === 'logged') {
        allow = true ;
      }
      return true;

    }
}
