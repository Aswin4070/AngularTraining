import { Component, OnInit } from '@angular/core';
import { CompInteractionService } from '../comp-interaction.service';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

loginForm: FormGroup;

formConfig = [
  {label: 'User Name', type: 'text', name: 'username', constraint: Validators.required},
  {label: 'Password', type: 'password', name: 'password', constraint: Validators.required}
];

  constructor(private service: CompInteractionService, private builder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.builder.group({});
    this.formConfig.forEach(eachConfig => {
      this.loginForm.addControl(eachConfig.name,
        new FormControl('', {validators: eachConfig.constraint}));
    });
  }

  signIn() {
      this.service.changeCurrentStatus('logged');
      const uname = this.loginForm.controls.username.value;
      const pword = this.loginForm.controls.password.value;

      if ( uname === 'india' && pword === 'delhi') {
        sessionStorage.setItem('status', 'logged');
        this.router.navigate(['home']);
      }

  }

}
