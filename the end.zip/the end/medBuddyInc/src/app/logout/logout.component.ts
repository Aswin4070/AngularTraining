import { Component, OnInit } from '@angular/core';
import { CompInteractionService } from '../comp-interaction.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private service: CompInteractionService) { }

  ngOnInit() {
  }
  signOut() {
    this.service.changeCurrentStatus('logged');
}

}
