import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  links: any;
  incFont = false;
  decFont = false;
  constructor() {
    this.links = [
      {linkText: 'twitter', linkCls: 'fa fa-twitter'},
      {linkText: 'facebook', linkCls: 'fa fa-facebook'},
      {linkText: 'instagram', linkCls: 'fa fa-instagram'}
    ];
  }

  ngOnInit() {
  }

  increaseFont() {
    this.incFont = true;
    this.decFont = false;
  }

  decreaseFont() {
    this.incFont = false;
    this.decFont = true;
  }


}
