import { Component, OnInit, Input } from '@angular/core';
import { CompInteractionService } from '../comp-interaction.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  @Input() linkList: string;
  showLogin = true;
  showLogout = false;
  constructor(private service: CompInteractionService) { }

  ngOnInit() {
    this.service.currentStatus.subscribe(message => {
      if (message === 'logged') {
        this.showLogin = false;
        this.showLogout = true;
      } else if (message === 'logout') {
        this.showLogin = true;
        this.showLogout = false;
      }
    });
  }

}
