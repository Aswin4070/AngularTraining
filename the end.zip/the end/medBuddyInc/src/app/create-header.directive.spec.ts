import { CreateHeaderDirective } from './create-header.directive';

describe('CreateHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new CreateHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
