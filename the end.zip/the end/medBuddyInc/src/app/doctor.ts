export interface Doctor {
    id: number;
    doctorName: string;
    location: string;
    specialization: string;
}
