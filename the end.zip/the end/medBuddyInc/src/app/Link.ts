export interface Link {
    linkText: string; linkRef: string;
    linkClass?: string; linkImage?: string;
}
