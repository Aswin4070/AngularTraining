import { Component, OnInit } from '@angular/core';
import { MedBuddyAPIService } from '../med-buddy-api.service';
import { Transaction } from '../transaction';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.css']
})
export class TransactionHistoryComponent implements OnInit {

  constructor(private service: MedBuddyAPIService, private active: ActivatedRoute) { }
  txnList: Transaction[];
  serchString = '';
  info = '';

  ngOnInit() {

    this.active.params.subscribe( pathParams => {
      const id = pathParams['txnId'];
      if ( id === undefined) { this.info = 'Loading'; } else {
       this.info = 'Details of id : = ' + id + ' will be loaded';
      }
    });

    this.service.findAllTransactions().then(
      resp => this.txnList = resp
    );
  }

}
