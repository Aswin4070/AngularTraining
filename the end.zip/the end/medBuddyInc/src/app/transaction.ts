export interface Transaction {
    id: number;
    detail: string;
    date: Date;
    value: number;
}
