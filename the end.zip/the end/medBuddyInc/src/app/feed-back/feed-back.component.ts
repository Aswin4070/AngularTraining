import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feed-back',
  templateUrl: './feed-back.component.html',
  styleUrls: ['./feed-back.component.css']
})
export class FeedBackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  getLatestReviews(): string[] {
    return ['Best and Timely Service'];
  }

  getBestReviews(): string[] {
      return ['*****, maggy.pune',
              '****, aswin.hyd'];
  }

}
