import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContentComponent } from './content/content.component';
import { TransactionHistoryComponent } from './transaction-history/transaction-history.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ShowstockComponent } from './showstock/showstock.component';
import { SearchHospitalComponent } from './search-hospital/search-hospital.component';
import { ManageDoctorsComponent } from './manage-doctors/manage-doctors.component';
import { UniversalGuardGuard } from './universal-guard.guard';


const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: ContentComponent},
  {path: 'history', component: TransactionHistoryComponent, canActivate: [UniversalGuardGuard]},
  {path: 'history/:txnId', component: TransactionHistoryComponent, canActivate: [UniversalGuardGuard]},
  {path: 'login', component: LoginComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'medicine', component: ShowstockComponent},
  {path: 'hospital', component: SearchHospitalComponent},
  {path: 'doctors', component: ManageDoctorsComponent},
  {path: '**', redirectTo: 'home'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
