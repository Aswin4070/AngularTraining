import { Component, OnInit, ViewChild } from '@angular/core';
import { MedBuddyAPIService } from '../med-buddy-api.service';
import { Doctor } from '../doctor';

@Component({
  selector: 'app-manage-doctors',
  templateUrl: './manage-doctors.component.html',
  styleUrls: ['./manage-doctors.component.css']
})
export class ManageDoctorsComponent implements OnInit {

  @ViewChild('frm') form: any;

  btnText = 'Add';
  status = false;

  doctor: Doctor = {
    id: 0,
    doctorName: '',
    location: 'chennai',
    specialization: ''
  };
  doctorList: Doctor[];
  editPos: number;
  constructor(private service: MedBuddyAPIService) { }

  ngOnInit() {
    this.service.getDoctors().subscribe(resp => this.doctorList = resp);
  }

  submit() {
    if (this.btnText === 'Add') {
      this.service.addDoctors(this.doctor).subscribe(resp => {
        console.log('added');
        this.doctorList.push(resp);
      } );
    } else {
      this.service.updateDoctorDetails(this.doctor).subscribe(resp => {
          console.log('updated');
        this.doctorList[this.editPos] = resp;
        this.form.reset();
        this.btnText = 'Add';
      });
    }
  }

  delete() {
    const inxPos = this.doctorList.indexOf(this.doctor);
    this.service.removeDoctor(this.doctor).subscribe(resp => {
      console.log('deleted');
      this.doctorList.splice(inxPos, 1);
    });
  }
  edit(eachDoctor: Doctor) {
    this.editPos = this.doctorList.indexOf(eachDoctor);
    this.doctor = eachDoctor;
    this.btnText = 'update';
    this.status = true;
  }
}
