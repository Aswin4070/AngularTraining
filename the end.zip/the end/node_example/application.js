
var calculator =require('./interestCalculator');

console.log(calculator.simpleInterest(5000,2,0.08));