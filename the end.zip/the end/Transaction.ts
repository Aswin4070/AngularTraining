export interface Transaction{
    id:number;
    trxDate:Date;
    details:string;
    value:number;
}