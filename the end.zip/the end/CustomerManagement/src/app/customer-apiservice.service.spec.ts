import { TestBed, inject } from '@angular/core/testing';

import { CustomerAPIServiceService } from './customer-apiservice.service';

describe('CustomerAPIServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomerAPIServiceService]
    });
  });

  it('should be created', inject([CustomerAPIServiceService], (service: CustomerAPIServiceService) => {
    expect(service).toBeTruthy();
  }));
});
