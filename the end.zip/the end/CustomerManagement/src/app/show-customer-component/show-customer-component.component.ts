import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { CustomerAPIServiceService } from '../customer-apiservice.service';

@Component({
  selector: 'app-show-customer-component',
  templateUrl: './show-customer-component.component.html',
  styleUrls: ['./show-customer-component.component.css']
})
export class ShowCustomerComponentComponent implements OnInit {

  customerList: Customer[];
  constructor(private service: CustomerAPIServiceService) { }

  ngOnInit() {
    this.service.findAllCustomers().subscribe(data => this.customerList = data);
  }

}
