import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowCustomerComponentComponent } from './show-customer-component.component';

describe('ShowCustomerComponentComponent', () => {
  let component: ShowCustomerComponentComponent;
  let fixture: ComponentFixture<ShowCustomerComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowCustomerComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowCustomerComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
