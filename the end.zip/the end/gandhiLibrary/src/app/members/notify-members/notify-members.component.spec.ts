import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifyMembersComponent } from './notify-members.component';

describe('NotifyMembersComponent', () => {
  let component: NotifyMembersComponent;
  let fixture: ComponentFixture<NotifyMembersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotifyMembersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifyMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
