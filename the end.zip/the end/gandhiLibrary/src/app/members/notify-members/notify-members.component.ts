import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notify-members',
  templateUrl: './notify-members.component.html',
  styleUrls: ['./notify-members.component.css']
})
export class NotifyMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
