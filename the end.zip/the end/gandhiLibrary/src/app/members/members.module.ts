import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MembersRoutingModule } from './members-routing.module';
import { AddMembersComponent } from './add-members/add-members.component';
import { NotifyMembersComponent } from './notify-members/notify-members.component';

@NgModule({
  imports: [
    CommonModule,
    MembersRoutingModule
  ],
  declarations: [AddMembersComponent, NotifyMembersComponent]
})
export class MembersModule { }
