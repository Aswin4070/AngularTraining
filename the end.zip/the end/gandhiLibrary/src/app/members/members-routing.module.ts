import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMembersComponent } from './add-members/add-members.component';
import { NotifyMembersComponent } from './notify-members/notify-members.component';

const routes: Routes = [
  {path: 'add', component: AddMembersComponent},
  {path: 'notify', component: NotifyMembersComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MembersRoutingModule { }
