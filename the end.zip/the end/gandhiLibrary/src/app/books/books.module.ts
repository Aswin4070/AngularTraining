import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowBookComponent } from './show-book/show-book.component';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [ShowBookComponent],
  declarations: [ShowBookComponent]
})
export class BooksModule { }
