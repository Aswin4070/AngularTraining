import { NgModule, Input } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowBookComponent } from './books/show-book/show-book.component';
import { MembersModule } from './members/members.module';
import { MembersRoutingModule } from './members/members-routing.module';

const routes: Routes = [
  {path: '', redirectTo: 'book', pathMatch: 'full'},
  {path: 'member', loadChildren: './members/members.module.ts#MembersModule'},
  {path: 'book', component: ShowBookComponent},
  {path: '**', redirectTo: 'book'}
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
